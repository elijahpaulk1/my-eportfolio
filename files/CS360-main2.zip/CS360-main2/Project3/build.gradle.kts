plugins {
    // No plugins in the root build.gradle.kts
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
