package com.example.project3;

import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);

        // Asynchronously load inventory items
        new LoadInventoryItemsTask().execute();
    }

    private class LoadInventoryItemsTask extends AsyncTask<Void, Void, ArrayList<InventoryItem>> {
        @Override
        protected ArrayList<InventoryItem> doInBackground(Void... voids) {
            return dbHelper.getAllInventoryItems();
        }

        @Override
        protected void onPostExecute(ArrayList<InventoryItem> inventoryItems) {
            RecyclerView recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(InventoryActivity.this));
            InventoryAdapter adapter = new InventoryAdapter(InventoryActivity.this, inventoryItems);
            recyclerView.setAdapter(adapter);
        }
    }
}
